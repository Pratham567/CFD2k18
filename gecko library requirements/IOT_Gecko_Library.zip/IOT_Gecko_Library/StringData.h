#define ok "OK"
#define err "Error"
#define InvalidUserIdOrPassword 18
#define InvalidData 45
#define VALID 24
#define error18 "18"
#define error45 "45"
#define RST  "AT+RST\r\n"
#define ATE  "ATE0\r\n"
#define CIPMUX  "AT+CIPMUX=1\r\n"
#define CWMODE   "AT+CWMODE=3\r\n"
#define CIPCLOSE   "AT+CIPCLOSE=4\r\n\r\n"
#define CIOBAUD   "AT+CIOBAUD=9600\r\n"
#define CWJAP   "AT+CWJAP=\""
#define IOTtest "GET /IOTHit.aspx?Id="
#define igpss "&Pass="
#define igdata "&Data="
#define igdata0 "&Data=0"
#define Host " HTTP/1.1\r\nHost: www.iotgecko.com\r\n\r\n"
#define CIPSEND   "AT+CIPSEND=4,"
#define CIPSTART   "AT+CIPSTART=4,\"TCP\",\"www.iotgecko.com\",80\r\n"
#define wifiRX	2
#define wifiTX	3
