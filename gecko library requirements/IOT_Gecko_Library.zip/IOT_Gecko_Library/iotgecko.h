#ifndef iotgecko_h
#define iotgecko_h

#include "Arduino.h"
#include <SoftwareSerial.h>
#include "StringData.h"

class iotgecko
{
  public:
    iotgecko(long baud);
    bool GeckoConnect(String SSID, String PASS);
    bool GeckoReconnect();
    bool GeckoVerify(String id,String password);
    int GetgParams(int *data_buff, int totalData);
    int SendGParams(int *dataTosend, int sizeOFarray);
    //bool SendGParams(int *dataTosend, int sizeOFarray);

  private:
    bool sendCommand(String cmd,String response,int timeout,int debug); 
    void MakeGeckoHitSite();
    bool ChangeBaudTo9600(long baudToChange);
    void changeBaudifReqired();
    void resetWiFi();
    void flushdata();
    bool connectWiFi();
    bool GeckoConnectinReconnect();
    bool GeckoVerifyinReconnect();
};

#endif