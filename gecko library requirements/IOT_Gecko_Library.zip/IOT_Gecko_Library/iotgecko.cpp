#include <SoftwareSerial.h>
#include "Arduino.h"
#include "iotgecko.h"
#include "HardwareSerial.h"
#include "StringData.h"

SoftwareSerial esp8266(wifiRX , wifiTX);// RX, TX

String _id,_password,_SSID,_PASS,type_;
int _type;
int value,first;
int err_index;
char inChar;
long _baud;
String linkTogetsiteResponse="";
String linkTosendData="";
String lenghtOflinstr;
String finallinktoSenddata;
String espResponse="";
String data;
String chk_str="";

iotgecko::iotgecko(long baud)
{
  _baud = baud;
  Serial.begin(115200);
  esp8266.begin(baud);
  espResponse.reserve(2000);
}

// Public Methods //////////////////////////////////////////////////////////////
// Functions available in Wiring sketches, this library, and other libraries
bool iotgecko::GeckoConnect(String SSID, String PASS)
{
  _SSID = SSID;
  _PASS = PASS;
  if(connectWiFi())
    return true;
  else
    return false;
}

bool iotgecko::GeckoReconnect()
{
  sendCommand(CIPCLOSE,ok,5000,1);
  if(GeckoConnectinReconnect())
    if(GeckoVerifyinReconnect())
      return true;
    else
      return false;
  else
    return false;
}
bool iotgecko::GeckoVerify(String id,String password)
{
  if(sendCommand(CIPSTART,ok,5000,1))
  {
    _id = id;
    _password = password;
    MakeGeckoHitSite();
    return true;
  }
  else
  {
    return false;
  }
}

int iotgecko::GetgParams(int *data_buff, int totalData)
{
  sendCommand(CIPSEND,">",100,0);
  if(sendCommand(lenghtOflinstr,">",5000,1))
    if(sendCommand(linkTogetsiteResponse,F("</html>"),10000,1))
    {
      if(data.indexOf(err)>=0)
      {
        err_index = data.indexOf(err);
        data = data.substring(err_index+9,err_index+12);
        data.trim();
        if(data.indexOf(error18)>=0)
        {
          return InvalidUserIdOrPassword;
        }
        else if(data.indexOf(error45)>=0)
        {
          return InvalidData;
        }
      }
      else
      {
        data = data.substring(data.indexOf(F("pin="))+4,data.indexOf(F("pin="))+(4+totalData));
        for(int looptofilldata = 0 ; looptofilldata < totalData ; looptofilldata++)
        {
          data_buff[looptofilldata] = (data[looptofilldata] - 48);
        }
        return VALID;
      }
    }
    else
    {
      data_buff[0]=data_buff[1]=data_buff[2]=data_buff[3]=-1;
      return 1;
    }
  else
  {
    data_buff[0]=data_buff[1]=data_buff[2]=data_buff[3]=-1; 
    return 1; 
  }
}

//bool iotgecko::SendGParams(int *dataTosend, int sizeOFarray)
//{
//  finallinktoSenddata = linkTosendData + (String)dataTosend[0];
//  for(int loopForarry=1 ; loopForarry < sizeOFarray ; loopForarry++)
//  {
//    finallinktoSenddata += '*';
//    finallinktoSenddata += (String)dataTosend[loopForarry];
//  }
//  sendCommand(CIPSEND,">",100,0);
//  finallinktoSenddata += Host; 
//  lenghtOflinstr=String(finallinktoSenddata.length()) + "\r\n" ; 
//  if(sendCommand(lenghtOflinstr,">",5000,1))
//    if(sendCommand(finallinktoSenddata,F("</html>"),10000,1))
//      return true;
//    else
//      return false;
//  else
//    return false;
//}

int iotgecko::SendGParams(int *dataTosend, int sizeOFarray)
{
  finallinktoSenddata = linkTosendData + (String)dataTosend[0];
  for(int loopForarry=1 ; loopForarry < sizeOFarray ; loopForarry++)
  {
    finallinktoSenddata += '*';
    finallinktoSenddata += (String)dataTosend[loopForarry];
  }
  sendCommand(CIPSEND,">",100,0);
  finallinktoSenddata += Host; 
  lenghtOflinstr=String(finallinktoSenddata.length()) + "\r\n" ; 
  if(sendCommand(lenghtOflinstr,">",5000,1))
    if(sendCommand(finallinktoSenddata,F("</html>"),10000,1))
    {
//      Serial.print("data=");
//      Serial.println(data);
      if((data.indexOf(err)>=0))// || (data.indexOf("No.")>=0) || (data.indexOf("Invalid")>=0))
      {
        err_index = data.indexOf(err);
        data = data.substring(err_index+9,err_index+12);
        data.trim();
        if(data.indexOf(error18)>=0)
        {
          return InvalidUserIdOrPassword;
        }
        else if(data.indexOf(error45)>=0)
        {
          return InvalidData;
        }
      }
      else
      {
        return VALID;
      }
    }
    else
      return false;
  else
    return false;
}

// Private Methods /////////////////////////////////////////////////////////////
// Functions only available to other functions in this library

bool iotgecko::sendCommand(String cmd,String response,int timeout,int debug) 
{
  esp8266.print(cmd);
//  Serial.println(cmd);
  chk_str="";
  espResponse="";  
  first=0;
  espResponse.reserve(1000);
  if(debug==1)
  {
    long current_time=millis();
    while(1)
    {
       espResponse="";
       while(esp8266.available()>0)
       {
          inChar = (char)esp8266.read();
          if((inChar!='\n') || (inChar!='\r')) 
          {
            espResponse += inChar; 
          }        
          if((inChar=='\n') || (inChar=='\r'))   
          {
            break;
          }
          if(first==1)
          {
           data+=inChar;
          }
       }
       espResponse.trim();
       if(((espResponse.indexOf(F("pin"))>=0) || (espResponse.indexOf(F("</div>"))>=0) || (espResponse.indexOf(F("<center>"))>=0)) && (first==0))
       {
         first++;
         data = espResponse;
         espResponse="";
       }
       if(espResponse.indexOf(F("<tr>"))>=0)
       {
          first++;
       }
       else if((espResponse.endsWith(F("ERROR)")) || (espResponse.endsWith(F("FAIL")))))
       {
          return false;
       }
       if(espResponse.startsWith(F("busy")))
       {
          current_time=millis();
       }
       if((current_time+timeout) < millis())
       {
          return false;
       }
       if(espResponse.indexOf(response)>=0)
       {
          esp8266.flush();
          return true;
       } 
    }    
  }
  return 0;
}

void iotgecko::MakeGeckoHitSite()
{
  linkTogetsiteResponse = IOTtest + _id + igpss + _password + igdata0 + Host;
  linkTosendData = IOTtest + _id + igpss + _password + igdata;  
  lenghtOflinstr=String(linkTogetsiteResponse.length()) + "\r\n" ; 
}

bool iotgecko::connectWiFi()
{
  resetWiFi();
  changeBaudifReqired();
  if(sendCommand(ATE,ok,1000,1)) 
    if(sendCommand(CIPMUX,ok,2000,1)) 
      if(sendCommand(CWMODE,ok,2000,1)) // configure as access point
        if(sendCommand(CWJAP + _SSID + "\",\"" + _PASS + "\"\r\n",ok,10000,1))
          return true;
        else
          return false;
      else
        return false;
    else
      return false;
  else
    return false;
}
void iotgecko::changeBaudifReqired()
{
  if(_baud!=9600)
  {
    ChangeBaudTo9600(_baud);  
  }
}
void iotgecko::resetWiFi()
{
  sendCommand(RST,F("ready"),2000,1);// reset module
  flushdata();
}
void iotgecko::flushdata()
{
  esp8266.flush();
}
bool iotgecko::ChangeBaudTo9600(long baudToChange)
{
  esp8266.begin(baudToChange);
  delay(1000);
  sendCommand(CIOBAUD,ok,2000,1);
  delay(1000);
  esp8266.begin(9600);
  return true;
}
bool iotgecko::GeckoVerifyinReconnect()
{
  if(sendCommand(CIPSTART,ok,5000,1))
  {
    MakeGeckoHitSite();
    return true;
  }
  else
  {
    return false;
  }
}
bool iotgecko::GeckoConnectinReconnect()
{
  if(connectWiFi())
    return true;
  else
    return false;
}